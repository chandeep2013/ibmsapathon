sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/viz/ui5/controls/Popover"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, Popover) {
        "use strict";

        return Controller.extend("com.sap.sapathon.controller.View1", {
            onInit: function () {
                //this.oOwnerComponent = this.getOwnerComponent();
                //this.oRouter = this.oOwnerComponent.getRouter();
                //this.oRouter.getRoute("HrbpReports").attachPatternMatched(this._onvizCharts, this);
                var that= this;
                var oVizFrame1 = this.getView().byId("idVizFrame1");
			    var oPopOver1 = this.getView().byId("idPopOver1");
			    oPopOver1.connect(oVizFrame1.getVizUid());
                oPopOver1.setActionItems([{
                    type: 'action',
                    text: 'View Details',
                    press: function() {
                        var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
                        oRouter.navTo("View2");
                    }
                }]);
                oVizFrame1.setVizProperties({
                    title: {
                        text: 'Column Chart'
                    },
                    plotArea: {
                        colorPalette: ["#8189F7", "#E8743B", "#19A979", "#ED4A7B", "#8189F7", "#E8743B", "#19A979", "#ED4A7B"]
                    }
                });
                var oVizFrame2 = this.getView().byId("idVizFrame2");
			    var oPopOver2 = this.getView().byId("idPopOver2");
			    oPopOver2.connect(oVizFrame2.getVizUid());
                oPopOver2.setActionItems([{
                    type: 'action',
                    text: 'View Details',
                    press: function() {
                        var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
                        oRouter.navTo("View2");
                    }
                }]);
                oVizFrame2.setVizProperties({
                    title: {
                        text: 'Combination Chart'
                    },
                    plotArea: {
                        dataShape: {
                            primaryAxis: ['bar', 'bar', 'line', 'line'],
                            secondaryAxis: ['line', 'line']
                        },
                        colorPalette: ["#8189F7", "#E8743B", "#19A979", "#ED4A7B", "#8189F7", "#E8743B", "#19A979", "#ED4A7B"]
                    }
                });
                this._onvizCharts();
            },
            _onvizCharts: function () {
                var that = this;
                sap.ui.core.BusyIndicator.show(-1);
                $.ajax({
                    method: "GET",
                    contentType: "application/json",
                    url: "https://port4004-workspaces-ws-mgqj6.us10.trial.applicationstudio.cloud.sap/v2/catalog/SampleData",
                    async: true,
                    success: function (result) {
                        that.arrangeData(result.d.results);
                    },
                    error: function (errorThrown) {
                        console.log(errorThrown);
                    }
                });
            },
            arrangeData: function (ResponseData) {
                var oModel = new JSONModel();
                oModel.setSizeLimit(100000);
                var ViZData= [];
                var pgmName = 0, ResponseDataPgmName = 0, ProgramRunPerMonth = 0,Co2EmissioninGrams=0;
                for (var i = 0; i < ResponseData.length; i++) {
                    if(ResponseData[i+1] && ResponseData[i].executionMonth === ResponseData[i+1].executionMonth){
                        if(ResponseData[i].programName != ""){
                            ResponseDataPgmName = 1;
                        }
                        pgmName += ResponseDataPgmName;
                        ProgramRunPerMonth += parseInt(ResponseData[i].noOfTimesThePgmRunForTheMonth);
                        Co2EmissioninGrams += parseInt(ResponseData[i].co2EmissioninMG);
                    }
                    else{
                        ViZData.push({
                            "Month": ResponseData[i].executionMonth,
                            "Program Name": pgmName,
                            "Program Run Per Month": ProgramRunPerMonth,
                            "Co2 Emission in g": Co2EmissioninGrams
                        });
                    }
                }
                console.log(ViZData);
                sap.ui.core.BusyIndicator.hide();
                oModel.setData(ViZData);
                this.getView().setModel(oModel, "vizData");
                
            }
        });
    });
